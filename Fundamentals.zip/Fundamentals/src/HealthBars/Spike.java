/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HealthBars;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

/**
 *
 * @author stu48426
 */
public class Spike extends Rectangle {

    public Spike() {
        super(0, 0, 4, 4);
        Random randy = new Random();
        x = randy.nextInt(500);
        y = randy.nextInt(500);
    }

    public void draw(Graphics g) {
    g.setColor(Color.orange);
    g.fillOval(x, y, width, height);
    }
}
