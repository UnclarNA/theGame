/**
 *
 * @donoven.ballard
 */

import java.util.*;
import java.text.*;
import java.io.*;
import java.lang.*;
import javax.swing.*;

public class donow {
    public static void main(String[] args) throws Exception { 
     String adultNum=JOptionPane.showInputDialog("how many adults are here? ");
     int adults=new Integer(adultNum);
     String childtNum=JOptionPane.showInputDialog("how many kids are here? ");
      int childs=new Integer(childtNum);
       double childsCost=0;
       double adultsCost=0; 
       double beverageCost=0;
     if (childs > adults){
       adultsCost=5;
       childsCost=4;
     JOptionPane.showMessageDialog(null, "you will have pizza" );}
     else{
       adultsCost=5.50;
       childsCost=5.50;
        JOptionPane.showMessageDialog(null, "you will have chicken" );}
    if(childs>0){
        beverageCost=1.25;
        JOptionPane.showMessageDialog(null, "you will have lemonade");}
    else{
        beverageCost=1.50;
        JOptionPane.showMessageDialog(null, "you will have tea" );}
     double totalCost=childs*childsCost+ adults*adultsCost+ (adults+childs)* beverageCost;
     JOptionPane.showMessageDialog(null, "total cost"+totalCost);
     
    }

}
