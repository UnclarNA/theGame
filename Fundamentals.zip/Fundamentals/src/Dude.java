
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author stu48426
 */
public class Dude extends Rectangle {

    boolean up, down, left, right;
    double xSpeed, ySpeed, xD, yD;
    boolean player1;
    int rotation;
    int hitPoints;
    final int MAX_HIT_POINTS = 100;

    public Dude(int x1, int y1) {
        super(x1, y1, 50, 30);
        up = down = left = right = false;
        xD = x;
        yD = y;
        xSpeed = 1;
        ySpeed = 0;
        rotation = 0;
        player1 = false;
        hitPoints = MAX_HIT_POINTS;
    }

    public Dude() {
        super(210, 210, 50, 30);
        up = down = left = right = false;
        xD = x;
        yD = y;
        xSpeed = 1;
        ySpeed = 0;
        rotation = 0;
        player1 = false;
        hitPoints = MAX_HIT_POINTS;
    }

    public boolean isPlayer1() {
        return player1;
    }

    public void setPlayer1(boolean player1) {
        this.player1 = player1;
    }

    public void draw(Graphics g) {

        String text = "red";
        if (!player1) {
            text = "green";
        }
        System.out.println(text + "." + rotation);
        Image img = new ImageIcon(text + rotation + ".png").getImage();
        g.drawImage(img, x, y, width, height, null);
//       g.setColor(Color.red);
//        if(rotation%2==0)
//        g.fillRect(x, y, width, height);
//       else{
//            Polygon diamond=new Polygon();
//            diamond.addPoint(x, y+height/2);
//            diamond.addPoint(x+width/2, y+height);
//            diamond.addPoint(x+width, y+height/2);
//            diamond.addPoint(x+width/2, y);
//            g.fillPolygon(diamond);
//        
//        
//    }
        g.setColor(Color.BLACK);
        g.drawString(hitPoints + "/" + MAX_HIT_POINTS, x, y + height / 2);

        g.setColor(Color.red);
        g.fillRect(x, y, width, 3);

        g.setColor(Color.green);
        g.fillRect(x, y, width * hitPoints / MAX_HIT_POINTS, 3);
    }

    public void getHit() {
        hitPoints--;
    }

    public void move() {
        if (rotation == 0) {
            xSpeed = 1;
            ySpeed = 0;
        }
        if (rotation == 1) {
            xSpeed = .5;
            ySpeed = .5;
        }
        if (rotation == 2) {
            xSpeed = 0;
            ySpeed = 1;
        }
        if (rotation == 3) {
            xSpeed = -.5;
            ySpeed = .5;
        }

        if (rotation == 4) {
            xSpeed = -1;
            ySpeed = 0;
        }
        if (rotation == 5) {
            xSpeed = -.5;
            ySpeed = -.5;
        }
        if (rotation == 6) {
            xSpeed = 0;
            ySpeed = -1;
        }
        if (rotation == 7) {
            xSpeed = .5;
            ySpeed = -.5;
        }
        ////////
        if (up) {
            moveUp();
        }
        if (down) {
            moveDown();
        }
        if (right) {
            moveRight();
        }
        if (left) {
            moveLeft();
        }
    }

    public void moveUp() {
        xD += xSpeed;
        yD += ySpeed;
        x = (int) Math.round(xD);
        y = (int) Math.round(yD);
    }

    public void moveDown() {
        xD -= xSpeed;
        yD -= ySpeed;
        x = (int) Math.round(xD);
        y = (int) Math.round(yD);
    }

    public void moveRight() {
        rotation++;
        if (rotation == 8) {
            rotation = 0;
        }
    }

    public void moveLeft() {
        rotation--;
        if (rotation == -1) {
            rotation = 7;
        }
    }

    public void setUp(boolean up) {

        this.up = up;

    }

    public void setDown(boolean down) {

        this.down = down;

    }

    public void setLeft(boolean left) {

        this.left = left;

    }

    public void setRight(boolean right) {

        this.right = right;

    }
    
    public boolean dead(){
        return hitPoints<0;
    }

}
